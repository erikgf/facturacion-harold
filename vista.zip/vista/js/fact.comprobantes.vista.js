var app = {},
  DT = null,
  alertsW = {},
  RUC = "20603860871",
  tipoproceso = false ? "produccion" : "beta",
  seleccionados = [],
  INTERVALO_EMISION_GLOBAL = 3 * 1000,
  _enviandoComprobante = false,
  _modoGlobal = false;

app.init = function(){
  this.setDOM();
  this.setEventos();
  this.setTemplate();
};

app.setDOM = function(){
  var DOM = {};

  DOM.listado = $("#listado");
  DOM.listadoBody = $("#listado-body");

  DOM.txtFechaDesde = $("#txtfechadesde");
  DOM.txtFechaHasta = $("#txtfechahasta");
  DOM.chkTodos = $("#chktodos");
  DOM.cboEstado = $("#cboestado");
  DOM.btnBuscar = $("#btnbuscar");
  DOM.btnExcel = $("#btnexcel");
  DOM.btnGenerar = $("#btngenerarenviar");
  DOM.alertGlobal = $("#alert-blk-global");
  DOM.alert = $("#alert-blk");

  this.DOM = DOM;
};

app.setEventos  = function(){
  const DOM = this.DOM;

  DOM.chkTodos.on("change", function(e){
    const checked = this.checked;
    DOM.txtFechaDesde.prop("disabled", checked);
    DOM.txtFechaHasta.prop("disabled", checked);
  });

  DOM.btnBuscar.on("click", (e) => {
    e.preventDefault();
    this.listar();
  });

  DOM.cboEstado.on("change", (e) => {
    e.preventDefault();
    this.listar();
  });

  DOM.listadoBody.on("change", "tr td .chkselect", (e) => {
    //var id = this.parentElement.parentElement.dataset.id;
    e.preventDefault();
    this.cambioCheck( e.currentTarget );
  });

  DOM.btnGenerar.on("click", (e) => {
    e.preventDefault();
    if (seleccionados.length){
      this.generarEnviarGlobal();
    }
  });

  DOM.btnExcel.on("click", (e) => {
    e.preventDefault();
    const sentData = {
      tipo: DOM.chkTodos[0].checked,
      fecha_inicio: DOM.txtFechaDesde.val(),
      fecha_fin: DOM.txtFechaHasta.val(),
      key : JSON.parse(localStorage.getItem(SESSION_NAME)).token
    };

    Util.downloadPDFUsingPost({
      url: "../controlador/reporte.xls.comprobantes.php",
      variableName: "p_data", 
      JSONData: JSON.stringify(sentData)
    });
  });
};

app.cambioCheck = function($checkbox){
     var  $tr =  $checkbox.parentElement.parentElement,
          dataset = $tr.dataset,
          tipo = ($checkbox.checked == true ? "+" : "-"),
          $btnGenerar = this.DOM.btnGenerar;

     if (tipo == "+"){
        seleccionados.push({
          id: dataset.id,
          comprobante : dataset.comprobante,
          $tr : $tr
        });
      
        $($tr).addClass("tr-seleccionado");
     } else {
        for( var i = 0; i < seleccionados.length; i++){ 
           if ( seleccionados[i].id === dataset.id) {
             seleccionados.splice(i, 1); 
             $($tr).removeClass("tr-seleccionado");
           }
        }
     }
      
      if (seleccionados.length){
        $btnGenerar.attr("disabled",false);
      } else {
        $btnGenerar.attr("disabled",true);
      }
};

app.setTemplate = function(){
  this.tpl8= {
    listado : Handlebars.compile($("#tpl8Listado").html())
  };
};

app.listar = async function(){
  const DOM = app.DOM;
  try {
    const sentData = {
      todas_fechas: DOM.chkTodos[0].checked ? 1 : 0,
      fecha_inicio: DOM.txtFechaDesde.val(), 
      fecha_fin: DOM.txtFechaHasta.val(),
      estado: DOM.cboEstado.val()
    };
    const paramsData = new URLSearchParams(sentData);
    const { data } = await apiAxios.get(`comprobantes/generacion?${paramsData.toString()}`);
    app.renderLista(data);
  } catch (error) {
    swal("Error", JSON.stringify(error), "error");
    console.error(error);
  }
};

app.renderLista = function(data){
  const DOM = app.DOM;
  if (DT) { DT.fnDestroy(); DT = null; }
  DOM.listadoBody.html(app.tpl8.listado(data));
  DT = DOM.listado.find("table").dataTable({
    "aaSorting": [[0, "asc"]],
    responsive: true
  });
};

var mostrarAlert = function(mensaje, tipo, nombre_comprobante){
  var titulo = (tipo == "e" ? "Error" : (tipo == "w" ? "Procesando" : "OK")),
      classError = (tipo == "e" ? "danger" : (tipo == "w" ? "warning" : "success")),
      icono = (tipo == "e" ? "close" : (tipo == "w" ? "bullhorn" : "check")),
      html = '<div class="col-xs-12"><div class="alert alert-'+classError+'" style="margin:0px">';
      html += '<button type="button" class="close" data-dismiss="alert"><i class="ace-icon fa fa-times"></i></button>';
      html += '<strong> <i class="ace-icon fa fa-'+icono+'"></i> '+titulo+'!</strong>';
      html += ' '+mensaje+'<br>';
      html += '</div></div>';

  if (tipo == "w"){
    $html = $(html);
    app.DOM.alert.append($html);
    alertsW[nombre_comprobante] = $html;
  } else {
    app.DOM.alert.append(html);
  }
};

app.generarEnviarSUNAT = function(codTransaccion, nombre_comprobante, enviandoDesdeGlobal){
  var self = this,
    fn = function(xhr){
      var datos = xhr.datos;

      alertsW[nombre_comprobante].remove();
      alertsW[nombre_comprobante] = null;
      delete alertsW[nombre_comprobante];

      if (datos.respuesta == "error"){
        mostrarAlert(nombre_comprobante+" - "+datos.mensaje, "e");
      } else {
        mostrarAlert(nombre_comprobante+" - "+datos.msj_sunat, "s");
        if (!enviandoDesdeGlobal){
            self.listar();
        }
      }

      if (enviandoDesdeGlobal){
        for( var i = 0; i < seleccionados.length; i++){ 
          var obj =seleccionados[i], $tr;
           if ( obj.id === codTransaccion) {
             seleccionados.splice(i, 1); 
             $tr = $(obj.$tr);
             $tr.removeClass("tr-seleccionado");
             obj.$tr.children[0].children[0].checked = false;
            _enviandoComprobante = false;
           }
        }

        if (!seleccionados.length){
          self.DOM.alertGlobal.empty();
          _modoGlobal = false;
          _enviandoComprobante = false;
          self.listar();
        }
      }
    };

  if (codTransaccion == null || codTransaccion == ""){
    return;
  }

  if (enviandoDesdeGlobal == undefined){
    enviandoDesdeGlobal  = false;
  }

  if (_modoGlobal == true && enviandoDesdeGlobal == false){
    return;
  }
  mostrarAlert("Generando y enviando comprobante: "+nombre_comprobante+"....", "w",nombre_comprobante);

  new Ajxur.Api({
    modelo: "Comprobante",
    metodo: "generarEnviarSunat",
    data_in: {p_codTransaccion: codTransaccion}
  },fn);
};

var descargarArchivo = function(contenidoEnBlob, nombreArchivo) {
    var reader = new FileReader();
    reader.onload = function (event) {
        var save = document.createElement('a');
        save.href = event.target.result;
        save.target = '_blank';
        save.download = nombreArchivo || 'COMPROBANTE.XML';
        var clicEvent = new MouseEvent('click', {
            'view': window,
                'bubbles': true,
                'cancelable': true
        });
        save.dispatchEvent(clicEvent);
        (window.URL || window.webkitURL).revokeObjectURL(save.href);
    };
    reader.readAsDataURL(contenidoEnBlob);
};

var generarXml = function(textoXML, archivoXML) {
    return new File([textoXML], archivoXML, {type: "application/xml"});
    /*
    new Blob(textoXML, {
        type:  type: 'text/plain'
    });
    */
};

app.descargarXML = function(nombre_comprobante){
  console.log({nombre_comprobante})
  /*
  var archivoXML = RUC+"-"+tipo_comprobante+"-"+nombre_comprobante+".XML";
  $.get("../sistema_facturacion/archivos_xml_sunat/cpe_xml/"+tipoproceso+"/"+RUC+"/"+archivoXML).done(function(objXML, a, b){
    descargarArchivo(generarXml(b.responseText), archivoXML);
  });
  */
};

app.verComprobante = function(idComprobante){
  const sentData = {
    id : idComprobante,
    key : JSON.parse(localStorage.getItem(SESSION_NAME)).token
  };
  
  Util.downloadPDFUsingPost({
    url: "../impresiones/comprobante.ticket.pdf.php",
    variableName: "p_data", 
    JSONData: JSON.stringify(sentData)
  }); 
};

app.enviarCorreo = function(codTransaccion, correo, tipo_comprobante, nombre_comprobante){

  var fn = function(xhr){
    console.log(xhr);
  },
  fnError = function(error){
    console.log(error);
  };

  new Ajxur.Api({
    modelo: "Comprobante",
    metodo: "enviarCorreo",
    data_in: {p_codTransaccion: codTransaccion},
    data_out : [correo, tipo_comprobante, nombre_comprobante, null]
  },fn, fnError);
};

app.generarEnviarGlobal =function(){
  var fnAccion, interval, self= this;

  _modoGlobal = true;
  fnAccion = function(){
        var len = seleccionados.length,
            str = "",
            fnHtmlAlert =  function(txt){
              return '<div class="col-xs-12"><div class="alert alert-success" style="margin:0px"><strong> <i class="ace-icon fa fa-check"></i> Mensaje:</strong> '+txt+'<br></div></div>';        
            },
            primerComprobante = null;

        if (_enviandoComprobante == true){
          return;
        }

        if (_modoGlobal == false || !len ){          
          clearInterval(interval);                    
          return;
        }
        //Generar cadena.
        txt = "Se están procesando los siguientes comprobantes: ";
        for (var i = 0; i < len; i++) {
          var obj = seleccionados[i];
          txt += obj.comprobante + ",";
          if (i == 0){
            primerComprobante = obj;
          }
        };
  
        txt = txt.substring(0, txt.length - 1)+".";      
        self.DOM.alertGlobal.html(fnHtmlAlert(txt));
        /*Enviar ultimo comprobante*/
        _enviandoComprobante = true;
        self.generarEnviarSUNAT(primerComprobante.id, primerComprobante.comprobante, true);
      },
  interval;


  interval = setInterval(fnAccion, INTERVALO_EMISION_GLOBAL);

  fnAccion();

};

$(document).ready(function(){
  new AccesoAuxiliar(()=>{
    app.init();
  })
});

