<?php
	require_once(__DIR__ . "/obj.php");
	require_once(__DIR__ . "/curl.php");
	require_once(__DIR__ . "/sunat.php");
?>
