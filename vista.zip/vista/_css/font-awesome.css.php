
<!-- 

<link rel="stylesheet" href="../assets/css/font-awesome.min.css" />
<link rel="stylesheet" href="../assets/font-awesome-4.3.0/css/font-awesome.css" />

-->
<?php 
  if (MODO_PRODUCCION == "1"){
                echo '  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css" />
                        <link rel="stylesheet" href="../assets/css/fonts.googleapis.com.css" />';

            } else {

                echo '  <link rel="stylesheet" href="../assets/font-awesome/4.5.0/css/font-awesome.min.css" />
                        <!-- <link rel="stylesheet" href="../assets/css/fonts.googleapis.com.css" /> -->';

            }

 ?>
